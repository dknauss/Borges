=== Borges Bibliography Builder ===
Contributors: dpknauss
Donate link: https://github.com/sponsors/dknauss
Tags: bibliography, citation, doi, bibtex, academic
Requires at least: 6.4
Tested up to: 7.1
Stable tag: 1.18.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create accessible, structured bibliographies from DOI, PubMed, BibTeX, RIS, CSL-JSON, free text, and manual entries — with RIS export.

== Description ==

Named for Jorge Luis Borges (1899–1986), the Argentine writer and librarian known for stories about infinite libraries, imaginary books, and labyrinths of knowledge, Borges Bibliography Builder brings order to scholarly references in WordPress.

The **Borges Bibliography Builder** transforms DOI(s), PubMed/PMID records, BibTeX, RIS, CSL-JSON, manual entries, and supported free-text citations into a semantically rich, deduplicated, auto-sorted reference list with RIS export for citation managers.

**One-click import.** Paste a DOI and Crossref resolves the metadata instantly. Paste a PubMed/PMID identifier and Borges resolves it through an authenticated WordPress REST proxy to NCBI/PMC citation metadata. Paste BibTeX, RIS, or formatted citations for books, articles, chapters, webpages, reviews, and theses.

**Nine citation styles.** Choose from Chicago Notes-Bibliography, Chicago Author-Date, APA 7, MLA 9, Harvard, Vancouver, IEEE, OSCOLA, and ABNT (Associação Brasileira de Normas Técnicas / NBR 6023:2025) — all with automatic sorting per style rules, following each manual's current edition. Each style is a [Citation Style Language](https://citationstyles.org/) (CSL) file written for Borges and rendered by the citeproc-php engine.

**In-text and margin citations.** Choose Cite in any paragraph to link a short citation, such as "(Illich 1973, 12)" or a Chicago short note, to its entry in a bibliography on the same post. It works in running text and in a theme's margin-note paragraph style, and it is a plain link, so readers need no JavaScript.

**Portable.** Static HTML output survives plugin deactivation. No shortcodes. No database tables.

**Accessible by default.** Semantic list markup, keyboard-operable editing and entry reordering (Alt+Arrow for numeric styles), visible focus, and optional Block Accessibility Checks integration (requires that plugin at version 4.0 or later) help your bibliographies meet accessibility expectations.

**Reference-manager friendly.** Export and reuse your bibliography in common research workflows. Borges supports CSL-JSON, BibTeX, BibLaTeX, RIS, DOI links, JSON-LD, and optional COinS metadata for compatibility with tools such as Zotero, Mendeley, EndNote, JabRef, BibDesk, and other citation managers.

**Annotated bibliographies.** Add your own note to any entry, in as many paragraphs as you need, and turn on "Show annotations" to print each note under its entry. Notes are stored with the citation data (CSL `annote`), so they travel with CSL-JSON, BibTeX, BibLaTeX, and RIS. Off by default; existing bibliographies are unchanged.

**Reader-facing cite & export.** Optionally add a per-entry Cite / Export panel to the published bibliography: a disclosure under each entry with a copy button and one-click downloads in RIS, CSL-JSON, BibTeX, and BibLaTeX. The panel is built on the page, so newsletters and feeds carry a clean bibliography without it. Off by default; enable it per block.

**Try it first.** Launch a disposable demo in [WordPress Playground](https://playground.wordpress.net/?blueprint-url=https://raw.githubusercontent.com/dknauss/Borges/main/playground/blueprint.json) before installing it on your site.

**Translation-ready.** Plugin interface strings use the `borges-bibliography-builder` text domain, and official WordPress.org language packs are generated as community translations are approved on translate.wordpress.org.

**Support development.** If Borges saves you time by bringing order to your citations and joy to your heart, you can [sponsor the author](https://github.com/sponsors/dknauss) to support ongoing maintenance.

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/borges-bibliography-builder/`, or install directly through the WordPress plugin screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Add the "Bibliography" block to any post or page.
4. Paste DOI(s), PubMed/PMID identifiers, BibTeX, RIS, CSL-JSON, or supported citations for books, articles, chapters, and webpages — or add citations manually.

== Frequently Asked Questions ==

= Which translations are available? =

The WordPress.org plugin page's Languages list is the canonical list of currently published language packs. English (US) is the source language and is not counted as a translated locale; other locales appear after their Stable plugin translations are approved on translate.wordpress.org and a language pack is generated.

The package includes seed PO/MO files for translator review and import in French (`fr_FR`), German (`de_DE`), Dutch (`nl_NL`), Swedish (`sv_SE`), Spanish (`es_ES`), Italian (`it_IT`), Portuguese (`pt_PT`), Polish (`pl_PL`), Russian (`ru_RU`), Japanese (`ja`), Simplified Chinese (`zh_CN`), Korean (`ko_KR`), Serbian (`sr_RS`), Croatian (`hr`), Brazilian Portuguese (`pt_BR`), Hindi (`hi_IN`), Bengali (`bn_BD`), Tamil (`ta_IN`), and Telugu (`te`). These files cover plugin interface strings only and should not be read as official WordPress.org language-pack availability.

= What citation input formats does the Borges Bibliography Builder support? =

Bare DOIs, DOI URLs, PubMed/PMID identifiers, PubMed Central PMCIDs, arXiv IDs and links, ISBNs, OCLC numbers, LCCNs, Open Library edition IDs, Internet Archive item links and ARKs, BibTeX and BibLaTeX, RIS (single records or a whole `.ris` export), CSL-JSON, manual citation entries, and supported formatted citations for books, articles, chapters, webpages, reviews, and theses/dissertations. Free-text citations that include an inline DOI or labeled PMID are routed through the DOI/PubMed resolvers before falling back to the heuristic parser. You can paste multiple entries at once, up to 50 per paste, and each bibliography holds up to 200 citations in total.

= Does the ABNT style implement NBR 6023:2025? =

Yes. The ABNT option targets Associação Brasileira de Normas Técnicas bibliography formatting under NBR 6023:2025, uses the `pt-BR` locale, and defaults new ABNT bibliographies to the heading `Referências`. Always verify institutional or journal-specific ABNT variants before submission.

= What happens if I deactivate the Borges Bibliography Builder? =

Your bibliographies remain fully readable. The block uses static HTML output, so all formatted citations stay in your post content.

= What happens if I delete the Borges Bibliography Builder? =

Your bibliographies stay in your posts — they are saved as static HTML, not in a database table the plugin owns. When you delete the plugin, Borges removes only its own cached lookup data (transient and object-cache entries) and leaves your content untouched.

= ISBN lookups sometimes fail with a Google Books error. What can I do? =

Borges looks ISBNs up in Open Library first and falls back to Google Books. Without an API key, Google Books lookups share Google's anonymous daily quota with every other keyless caller, and that quota can run out. Create a key restricted to the Books API in the Google Cloud console and add it to `wp-config.php`:

`define( 'BIBLIOGRAPHY_BUILDER_GOOGLE_BOOKS_API_KEY', 'your-key' );`

Developers can supply or override it with the `bibliography_builder_google_books_api_key` filter instead. Borges stores no settings, so there is no settings screen for it.

= Does the Borges Bibliography Builder work with Zotero, Mendeley, EndNote, and other citation managers? =

Yes. Borges is built around portable bibliography formats rather than lock-in. Zotero can use DOI links, BibTeX, RIS, CSL-JSON, and optional COinS metadata. Mendeley and EndNote are best supported through BibTeX/RIS exports, with DOI-backed entries also friendly to browser importers. JabRef, BibDesk, and LaTeX/Biber workflows can use UTF-8 BibTeX or BibLaTeX. CSL-JSON is available for citeproc and scholarly data workflows.

= Why would I enable CSL-JSON? =

Enable CSL-JSON if you want your bibliography data to be reusable by scholarly tools, scripts, or services without scraping the visible citation text.

= Can I export the bibliography data? =

Yes. In the editor you can download the whole bibliography as CSL-JSON, BibTeX, BibLaTeX, or RIS, copy any single citation, or copy the full bibliography as plain text. You can also enable a per-entry Cite / Export panel that places the same RIS, CSL-JSON, BibTeX, and BibLaTeX downloads — plus the citation text — directly on the published page for your readers. The reader-facing panel is built on the page by a small script (no other script dependencies), stays out of newsletters and feeds, and is off by default.

= Can I access bibliography data via API? =

Yes. The plugin exposes read-only REST endpoints at `/wp-json/bibliography/v1/posts/<post_id>/bibliographies` and `/wp-json/bibliography/v1/posts/<post_id>/bibliographies/<index>` (or the block's `bibliographyId` in place of the index). Published posts are readable publicly; non-public posts require permission to edit the post. The single-bibliography route also supports `format=json`, `format=text`, and `format=csl-json`. Users who can edit the post can also validate a bibliography's entries, list likely duplicates, and preview it in another citation style (`/validate`, `/duplicates`, and `/preview?style=` under the block's index or `bibliographyId`); none of these saves anything. Editor-only authenticated endpoints handle CSL formatting and PubMed/PMID resolution; they do not persist citations by themselves. A site can also opt in to write routes that add, change, remove, and reorder citations, change block settings, and switch the citation style over REST. They are off unless a developer enables them with the `bibliography_builder_enable_write_routes` filter; see `docs/rest-write-routes.md` in the GitHub repository.

= Does the Borges Bibliography Builder work on WordPress Multisite? =

Yes. Borges works on WordPress Multisite, including network activation. If you encounter issues on a specific network configuration, please report them.

= What PHP and WordPress versions are supported? =

PHP 7.4+ and WordPress 6.4+. Borges Bibliography Builder is tested up to WordPress 7.1.

= Does Borges work with the Block Accessibility Checks plugin? =

Yes, and the integration is entirely optional. When Block Accessibility Checks 4.0 or later is active, the Bibliography block registers four authoring-time checks: an error when the block contains no citations, and warnings for a missing heading, for citations whose link text is a bare URL or DOI, and for having every machine-readable metadata output disabled. You can adjust each check's severity, or turn it off, from the Block Accessibility Checks settings screen.

Version 4.0 replaced the plugin's registration API, so the integration requires 4.0 or later. On Block Accessibility Checks 3.x the integration stays dormant and no bibliography checks appear. Borges itself is unaffected and works normally whether that plugin is outdated or not installed at all.

== Screenshots ==

1. Front-end bibliography output with hanging indents, italic titles, and linked DOIs, styled by the active theme.
2. Discover the Bibliography block in the block inserter by searching for "Bibliography."
3. Paste DOIs, PubMed/PMID identifiers, BibTeX, RIS, CSL-JSON, or free-text citations into the import form; hover any entry to reveal copy, edit, and delete actions.
4. Switch to Manual Entry to build a citation field by field — Publication Type, Author, Title, Container, Publisher, Year, Pages, DOI, and URL.
5. Correct imported or free-text citations in place with the structured field editor — fix individual fields without retyping the whole entry.
6. For numbered styles such as IEEE and Vancouver, reorder entries with the up and down controls (or Alt+Arrow keys) to set citation numbering.
7. Choose the citation style, the visible heading and its heading level, and toggle metadata output — JSON-LD, COinS, CSL-JSON, and the per-entry Cite / Export panel — from the block settings sidebar.
8. Export the whole bibliography from the sidebar: copy as plain text, or download CSL-JSON, BibTeX, BibLaTeX, or RIS.
9. Readers can expand the per-entry Cite / Export panel on the published page to copy a citation or download it as RIS, CSL-JSON, BibTeX, or BibLaTeX.

== Performance & Footprint ==

Borges is a static-output block. Formatted bibliography HTML, JSON-LD, and COinS are baked into your post content when you save, so the citeproc formatting engine and the DOI/PubMed lookups run **only in the editor** — never on the front end.

As a page renders, a light filter adds what the saved JSON-LD cannot know, such as the page's own URL for each entry's identifier, and extra identifiers and fields from the stored citations. It also marks each entry as an `h-cite` microformat for IndieWeb tools. It makes no database queries or remote requests.

What this means for a published page:

* **Zero added database queries** — no matter how many bibliographies or citations the page contains. Query load does not grow with your content.
* **No `render_callback`, no REST calls, no shortcodes** on the front end. Output is static HTML from the block's `save()`.
* **No long-lived settings** — the plugin registers no settings or autoloaded options, no custom tables, no custom post types, and no cron events. Editor-time PMID and formatting results are cached in the object cache and in short-lived, non-autoloaded transients, written only while editing. DOI imports are deduped in a browser-session cache, not stored server-side.
* **Tiny front-end payload** — only a small view script (~1.4 KB, with no dependencies) and stylesheet (~2.9 KB) load, and only on pages that actually contain a bibliography.

Installed footprint is roughly **1.9 MB** (the bundled citeproc-php formatting engine, translations, and editor/front-end assets account for the total). The latest v1.7.0 downloadable ZIP is **553,699 bytes** (about 541 KB compressed).

Because output is static, your bibliographies remain intact as plain HTML even if the plugin is deactivated.

== Known Limitations ==

**OSCOLA tables** — An OSCOLA bibliography that cites cases, legislation, or treaties lists them in a table of cases, a table of legislation, and a table of treaties before the secondary sources, as OSCOLA 5 asks. The tables are not divided by jurisdiction, statutes have no sub-entries for the sections cited, and "R v" cases file under R, which is OSCOLA's rule for works other than criminal-law works.

== Development ==

Full developer documentation, source code, issue tracker, and contribution guidelines are on GitHub:

[https://github.com/dknauss/Borges](https://github.com/dknauss/Borges)

Bug reports, feature requests, and pull requests are welcome. See CONTRIBUTING.md in the repository for development setup, coding standards, and the PR process.

== External Services ==

This plugin connects to fixed scholarly metadata services only when you explicitly add an identifier in the block editor — no citation data is sent automatically or in the background. No account or API key is required for any of the supported DOI, PMID, PMCID, arXiv, ISBN, library catalog, or Internet Archive lookups.

**DOI metadata**

DOI input connects to the **Crossref REST API** (https://api.crossref.org/) to resolve citation metadata.

* Crossref service: https://www.crossref.org/
* Crossref REST API documentation: https://api.crossref.org/swagger-ui/index.html
* Crossref privacy policy: https://www.crossref.org/privacy/
* Crossref terms of service: https://www.crossref.org/terms/

**PubMed/PMID and PubMed Central/PMCID metadata**

PubMed/PMID and PubMed Central/PMCID input connects through the plugin's authenticated WordPress REST proxy to the **NCBI/PMC Literature Citation Exporter** CSL endpoints. The proxy uses a fixed upstream host and validates the identifier as numeric before making the outbound request. Only the identifier is sent.

* NCBI APIs: https://www.ncbi.nlm.nih.gov/home/develop/api/
* NCBI/PMC Literature Citation Exporter: https://pmc.ncbi.nlm.nih.gov/api/ctxp/
* NLM Web Policies: https://www.nlm.nih.gov/web_policies.html

**arXiv metadata**

arXiv IDs, arxiv.org links, and arXiv DOIs connect through the plugin's authenticated WordPress REST proxy to the **arXiv API** (https://export.arxiv.org/api/query). The proxy uses a fixed upstream host and validates the arXiv ID pattern before making the outbound request. Only the arXiv ID is sent.

* arXiv API: https://info.arxiv.org/help/api/index.html
* arXiv API Terms of Use: https://info.arxiv.org/help/api/tou.html
* arXiv privacy policy: https://info.arxiv.org/help/policies/privacy_policy.html

**ISBN metadata**

ISBN input connects through the plugin's authenticated WordPress REST proxy to **Open Library** (https://openlibrary.org), run by the Internet Archive: its ISBN edition endpoint (https://openlibrary.org/isbn/) for the book record and its search API (https://openlibrary.org/search.json) for author names. If Open Library has no record or cannot be reached, the proxy falls back to the **Google Books API** (https://www.googleapis.com/books/v1/volumes). All upstream hosts are fixed, and the ISBN checksum is verified before any outbound request. Only the ISBN is sent, plus the site's own Google Books API key if one is defined in `wp-config.php` (the `BIBLIOGRAPHY_BUILDER_GOOGLE_BOOKS_API_KEY` constant). The key goes only to Google Books and is never sent to the browser.

* Open Library Books API (ISBN endpoint): https://openlibrary.org/dev/docs/api/books
* Open Library Search API: https://openlibrary.org/dev/docs/api/search
* Internet Archive terms of use: https://archive.org/about/terms.php
* Google Books APIs: https://developers.google.com/books
* Google APIs Terms of Service: https://developers.google.com/terms
* Google Privacy Policy: https://policies.google.com/privacy

**Library catalog numbers and Internet Archive items**

OCLC numbers, LCCNs, and Open Library edition IDs connect through the plugin's authenticated WordPress REST proxy to **Open Library's Books API** (https://openlibrary.org/api/books). Internet Archive item links, `ia:` identifiers, and Internet Archive ARKs connect to the **Internet Archive** item metadata API (https://archive.org/metadata/); an ARK is first matched to its item through the Internet Archive's advanced search (https://archive.org/advancedsearch.php). When the item lists its Open Library edition, ISBN, or LCCN, that identifier is then looked up through Open Library (with the Google Books fallback for an ISBN). All upstream hosts are fixed, and each identifier is validated before any outbound request. Only the identifier is sent.

* Open Library Books API: https://openlibrary.org/dev/docs/api/books
* Internet Archive developer documentation: https://archive.org/developers/
* Internet Archive terms of use: https://archive.org/about/terms.php

== Changelog ==

= 1.18.0 =
* **Added:** sentence case in APA 7, Vancouver, and IEEE. Titles imported in title case print in sentence case, as the manuals ask; the stored title never changes, so switching styles brings the capitals back. Languages, nationalities, countries, provinces, states, months, and days keep their capitals, and the `bibliography_builder_sentence_case_proper_nouns` filter adds your own. Other names can come out lowercase ("Darwin and wallace"), so each entry has a "Keep title capitalization as entered" checkbox. Existing blocks change only when their entries are next formatted.
* **Added:** journal abbreviations in IEEE and Vancouver, from the record's abbreviated title when it has one, with a new "Journal abbreviation" field in the entry editor.
* **Added:** OSCOLA repeated authors. One author's works come oldest first, and after the first the name becomes a double em dash, as OSCOLA 5 asks.
* **Changed:** new bibliographies start with an h2 heading, so they appear in the page's heading outline. Existing blocks keep their level; the `bibliography_builder_new_block_heading_level` filter sets another.
* **Changed:** the heading takes its size and weight from the theme's headings, and stays centred.
* **Changed:** citation links no longer carry `nofollow` or `noreferrer`, which told search engines not to trust the works you cite. They carry `rel="noopener"`, on saved posts too. The new `bibliography_builder_citation_link_rel` filter can restore `nofollow`.
* **Changed:** the bibliography is named by its visible heading (`aria-labelledby`) rather than a copy of it, on saved posts too.
* **Fixed:** the default heading keeps its look in newsletters and feeds, and two undated works by one author sort by title in author-date styles.

= 1.17.0 =
* **Added:** OSCOLA tables of primary sources. An OSCOLA bibliography with cases, legislation, or treaties lists them as OSCOLA 5 asks: a table of cases, then legislation, then treaties, then the bibliography of secondary sources. Existing blocks stay valid and take the new shape the next time they are edited.
* **Added:** on sites without Yoast SEO or Rank Math, the page's own `WebPage` structured data now links the cited works as schema.org `citation`. The new `bibliography_builder_page_citation_node` filter can change or drop it.
* **Changed:** Google's Rich Results Test no longer reports bibliographies as invalid items: each JSON-LD entry carries `item` without `url`. Encyclopedia and dictionary entries name their reference work.
* **Changed:** COinS names each entry's type, so Zotero's browser connector imports a chapter as a book section, a conference paper with its proceedings, and a book with its edition.
* **Fixed:** VoiceOver in Safari reads the bibliography as a list again ("list, 12 items", "7 of 12"). Saved posts need no change.
* **Fixed:** arXiv numbers print once in APA 7 and IEEE, not as "arXiv:arXiv:1706.03762".

= 1.16.0 =
* **Added:** RIS import. Paste a whole `.ris` export or single records from Zotero, Mendeley, EndNote, or another reference manager, alone or mixed with DOIs and formatted citations, and each record imports as a citation.
* **Added:** `wp borges duplicates`, a read-only report of repeated citations within each bibliography and across the bibliographies of one post. Bulk deduplicate now copies any field the kept copy lacks (a DOI, pages, a volume) from the copies it removes.
* **Changed:** richer structured data as pages render: magazine, newspaper, and web citations name their container in JSON-LD, conference papers are part of their proceedings, and COinS lists every author and the PubMed ID, so Zotero's browser connector imports the whole author list. Saved posts are unchanged. The new `bibliography_builder_enrich_coins` filter turns the COinS change off.
* **Fixed:** titles stored with straight apostrophes or quotation marks are now italicized.
* **Fixed:** BC dates. Years before 1000 now print in every style ("334 BCE", "731"; ABNT "334 AEC"), and string BC years in pasted CSL-JSON are kept.
* **Fixed:** sorting. In Chicago notes-bibliography and OSCOLA a single author sorts before co-authored works that begin with the same name, and ABNT files titles without Portuguese leading articles (O, A, Os, As, Um, Uma, Uns, Umas).
* **Fixed:** reference-manager imports: Mendeley's `city` field becomes the place of publication, BibTeX thesis and report types get readable genres, EndNote and Mendeley entries without cite keys import, comments in JabRef files are ignored, and pasted XML exports get a clear notice instead of becoming a citation.

= 1.15.0 =
* **Added:** bulk reformat across posts. With the write routes turned on, `POST /bibliography/v1/bulk/reformat` switches every bibliography in up to 25 posts to one citation style and saves each post once. It needs `edit_others_posts` plus `edit_post` on each post, previews unless `dry_run=false`, and returns the posts it did not reach as `remaining`. The `borges/bulk-reformat` ability and `wp borges reformat <post-id>... --style=<key> --user=<user>` do the same.
* **Added:** bulk deduplicate across posts. `POST /bibliography/v1/bulk/deduplicate`, the `borges/bulk-deduplicate` ability, and `wp borges deduplicate` remove repeated citations within each bibliography, keeping the first copy. A work listed in two bibliographies of one post is reported and left in place.
* **Added:** a rate limit for bulk edits: 250 posts per user per 15 minutes, dry runs included, and one saving bulk request at a time per site. Responses carry `RateLimit-*` headers; a request over the limit gets `429` with `Retry-After`. Filters let hosts change the numbers. WP-CLI commands spend no budget.
* **Fixed:** editing a citation can no longer turn it into a copy of another citation in the same bibliography. The block's field editor refuses the edit with a notice, and the REST update route and `borges/update-citation` ability return `409`. Repeats across two bibliographies on a page are still allowed.

= 1.14.0 =
* **Added:** WP-CLI commands. `wp borges list <post-id>` lists a post's bibliographies, `wp borges export <post-id>` prints one as CSL-JSON, plain text, or JSON, and `wp borges validate <post-id>` reports errors and warnings for every entry and exits 1 when there are errors. They change nothing. Without `--user` they read any post, as WordPress's own commands do; with `--user` they apply that user's permissions, the same as the REST API.
* **Fixed:** works by the same authors in the same year are told apart in APA, Chicago author-date, Harvard, and ABNT: "Jones, T. (2020a)." and "(2020b).", lettered in the order the bibliography lists them. Saved posts stay valid; a bibliography takes its letters the next time it is formatted (when a citation is added, edited, or removed, or the style changes). The REST write routes and abilities keep the letters current too.

= 1.13.0 =
* **Added:** richer structured data for search engines and AI crawlers. As a page renders, each cited work in the bibliography's JSON-LD gains an `@id`, its DOI, PMID, PMCID, arXiv, and ISBN identifiers with `sameAs` links, journal issue and volume, pages, editors and translators, and a closer schema.org type, and each entry links to its place on the page. Published posts get this without being edited. The `bibliography_builder_enrich_json_ld` filter turns it off.
* **Added:** with Yoast SEO or Rank Math, the page's Article lists the cited works under schema.org `citation`. The `bibliography_builder_link_page_citations` filter turns it off.
* **Added:** the `bibliography_builder_output_defaults` filter sets which outputs (JSON-LD, COinS, CSL-JSON, Cite / Export) a newly inserted bibliography starts with. Existing blocks keep their settings, and Borges still stores no settings.

= 1.12.0 =
* **Added:** write abilities for AI agents and automation on WordPress 6.9+ (add, update, delete, and reorder citations; change a bibliography's settings or style). They exist only when a site turns on the write routes with the `bibliography_builder_enable_write_routes` filter, and follow the same rules: `edit_post` on the post and a preview unless asked to save.
* **Fixed:** bibliographies in newsletters and feeds. Posts sent by email (Jetpack and WordPress.com newsletters, MailPoet, WooCommerce, Newspack) or read in a feed reader no longer show every reference in italics or a broken Cite / Export panel. Posts saved earlier are cleaned up as they are sent, and switch to the new markup the next time they are saved.
* **Fixed:** names with particles ("van Duijnhoven", "de la Cruz") sort where each style puts them: under the surname proper in Chicago and Vancouver, under the particle in APA, MLA, Harvard, and the others.
* **Fixed:** no period after a quoted title that ends in "?" or "!" in Chicago and MLA.
* **Changed:** reformatting after an edit is much faster in long bibliographies: only the changed entries are formatted, about 5 ms instead of 65–105 ms for 200 entries.
* **Changed:** internal restructuring and stricter static analysis, with no change to saved markup or output.

= 1.11.0 =
* **Fixed:** link cards no longer credit a cited source as the post's author. The JSON-LD listed cited works as top-level objects, and Mastodon takes the first top-level `WebPage` on a page to be the page itself, so a post citing a museum's collection page was shared "by Albertina". Cited works are now nested in one schema.org `ItemList`. Published posts are corrected as they are rendered, without being edited.
* **Fixed:** bibliographies over 50 citations. The server formatter now takes up to 200 entries per request, matching the editor, instead of falling back to plain titles with a "Formatter unavailable" notice.

= 1.10.0 =
* **Added:** library catalog numbers. Paste an OCLC number, an LCCN, or an Open Library edition ID (or their WorldCat, lccn.loc.gov, or Open Library links) and the book is looked up through Open Library. When Open Library has no record, Borges says so and suggests the ISBN.
* **Added:** Internet Archive items. Paste an archive.org item link, `ia:<identifier>`, or an Internet Archive ARK. Borges cites the edition the item names (its Open Library edition, ISBN, or LCCN) and keeps the archive.org page as the link, or tidies the scan's own record when it names none.
* **Added:** an optional Google Books API key for the ISBN fallback, set with the `BIBLIOGRAPHY_BUILDER_GOOGLE_BOOKS_API_KEY` constant or a filter, so lookups no longer depend on Google's shared anonymous quota. Borges still stores no settings.
* **Changed:** "Edit fields" now works on every citation, not only ones typed as free text. Only the fields you change are saved; untouched DOIs, URLs, authors, and dates stay exactly as imported.
* **Fixed:** a journal name that is part of its own DOI, such as eLife, is no longer italicized inside the DOI link, which split the link. Bibliographies saved with the broken link stay valid and are fixed the next time they are saved.
* **Fixed:** "Place: Publisher" in pasted citations (`London: Boyars, 1976`) is split into place and publisher.
* **Fixed:** Chinese, Japanese, and Korean author names, and names with a gloss in parentheses, are kept whole in book lookups; a leading Dr., Prof., Mr., Mrs., Ms., Mx., or Rev. is dropped.

= 1.9.1 =
* **Added:** pasting CSL-JSON, such as a reference manager's "CSL JSON" export, now imports each item as a citation. Items that are not valid citations are skipped and named, and JSON that is not CSL-JSON gets its own message.
* **Fixed:** a title the citation style puts in quotation marks, such as a web page in Chicago, is no longer also italicized.
* **Fixed:** the structured data (JSON-LD) link for a DOI keeps its slash, matching the visible link.
* Bibliographies saved with the old output stay valid and pick up the fixes the next time they are saved.

= 1.9.0 =
* **Added:** a Heading Level setting for the block's visible heading. Choose a level from 2 to 6 to print it as a real heading, so the bibliography appears in the page's heading outline and screen reader users can reach it by heading navigation. The default is still a paragraph, so existing bibliographies are unchanged. The heading keeps the same size at every level.

= 1.8.2 =
* **Fixed:** the edit form stores Title, Authors, Container title, Publisher, and Pages as plain text, as imports and manual entry already do. Markup typed or pasted into those fields is dropped on save instead of being stored in the citation.

= 1.8.1 =
* **Fixed:** HTML tags in a citation no longer show as text. An entry whose stored text or title carried tags, such as `<i>Governing the Commons</i>`, printed them literally; now `<i>` and `<em>` render as italics and other tags are dropped, in the bibliography, the editor, copied text, and exports. Affected bibliographies stay valid and pick up the fix the next time they are saved.

= 1.8.0 =
* **Current editions of four styles.** Chicago moves to the 18th edition (2024), Harvard to Cite Them Right 13 (2025), OSCOLA to its 5th edition (2026), and ABNT to NBR 6023:2025. Chicago now lists up to six authors before "et al.", books drop the place of publication in Chicago and Harvard, and OSCOLA and ABNT need no access date for a DOI. Existing bibliographies keep their saved text until an entry is added or edited or the style is changed.
* **New: MLA repeated authors.** In an MLA works-cited list, an entry by exactly the same authors as the one before it now starts with three hyphens, as the MLA Handbook asks. Screen readers still hear the names, and copied text and exports keep them in full. Existing MLA bibliographies stay valid and pick up the hyphens the next time they are saved.
* **New: Article number field.** Journal articles get an Article number field in the edit form and manual entry. Cite Them Right prints it as "article 108125" in place of pages, and DOI imports fill it automatically.
* **Fixed:** after an upgrade, cached formatting from an older style edition is no longer reused.

= 1.7.0 =
* **Better formatting in every citation style.** All nine styles are rewritten in full from their style manuals: Chicago (notes-bibliography and author-date), APA 7, MLA 9, Harvard, IEEE, Vancouver, OSCOLA, and ABNT. Entries now keep full given names, volume, issue, and pages, editors, translators, editions, and access dates, and follow each manual's author-list and "et al." rules. ABNT now prints in Portuguese, and Harvard uses British conventions. Existing bibliographies keep their saved text until an entry is added or edited or the style is changed.
* **Fixed: organization authors** (such as "Open Research Alliance") no longer vanish from formatted entries, and an entry after one shortened to "et al." keeps the "and" before its last author.
* **Fixed: "Attempt Block Recovery" in other languages.** A bibliography no longer opens as invalid when an editor using a different language from the one who saved it opens the post. Cite / Export labels are now translated for visitors as the page renders.
* **Fixed: wrong translations.** In all 19 bundled translations, seven strings such as "Copy citation" showed as "Add citations". They now fall back to English until corrected.
* **Fixed: whole `.bib` exports from reference managers.** Zotero abstracts with blank lines, JabRef comments and `@string` macros, and EndNote reference-type names no longer lose or garble records.
* **Fixed: duplicated blocks** no longer share IDs with the original, and pasting CSL-JSON is rejected instead of producing a nonsense citation.
* **New for developers: review and write routes.** Users who can edit a post can validate a bibliography, list likely duplicates, and preview it in another style over REST or as WordPress 6.9 abilities, without saving anything. Sites can also opt in to write routes that change citations, block settings, and the citation style over REST. They are off by default, preview every change first, and save through normal post revisions.
* **Playground demo:** the live demos open on a page with copy-ready samples of every input format and three example bibliographies.

= 1.6.0 =
* **New: PubMed Central import.** Paste a PMCID (`PMC3531190`) and it is looked up through the same NCBI service as PubMed IDs.
* **New: arXiv import.** Paste an arXiv ID, an arxiv.org link, or an arXiv DOI (`arXiv:1706.03762`, `10.48550/arXiv.1706.03762`) and it is looked up through the arXiv API. arXiv DOIs used to fail because Crossref doesn't hold them.
* **New: ISBN import.** Paste `ISBN 978-0-14-032872-1` or a labeled ISBN-10 and the book is looked up through Open Library, with Google Books as a fallback. Checksums are verified before any lookup, and a Google result is used only if it carries the exact ISBN you pasted.
* **New: BibLaTeX import** (`date`, `journaltitle`, `@online`, and similar) is now covered by tests. Formatted citations that contain a PMCID, arXiv ID, or labeled ISBN are looked up the same way as the bare identifier.
* **New: WordPress Abilities (WordPress 6.9 and later).** Three read-only abilities let AI assistants and automation tools list a post's bibliographies, export one as CSL-JSON or plain text, and check citation records, with the same permissions as the existing REST routes. Nothing can be changed through them.
* **Fixed: invalid language tags on imported entries.** BibTeX `language` and BibLaTeX `langid` values such as `ngerman` were saved verbatim into the entry's HTML `lang` attribute, which assistive technology cannot use. They now map to standard tags (`ngerman` → `de`); unknown values are left out. Already-saved entries are unchanged.
* **Fixed: arXiv links from BibTeX.** arXiv preprints pasted as BibTeX or BibLaTeX now keep a link to the abstract page instead of dropping the eprint.
* **Translations:** the translation template is back in sync with the plugin. A few help strings changed to name the new identifier types.
* **Privacy:** the External Services section now also lists arXiv, Open Library, and Google Books. Each is contacted only from the editor, only when you paste that kind of identifier, and receives only the identifier.

= 1.5.1 =
* **WordPress 7.1 support.** Verified against a 7.1 release candidate: the block registers and renders in the editor, which 7.1 now always runs inside an iframe, and bibliographies still format correctly in every citation style tested.
* **Fixed: copying could report failure when copying was still possible.** Both **Copy citation** and **Copy bibliography** had a fallback for browsers without clipboard access, but only used it when that access was missing entirely — not when the browser offered it and then refused. A refusal now falls through to the fallback instead of reporting failure.

= 1.5.0 =
**Security release. Updating is recommended for all sites.**

* Security: Fixed a denial-of-service weakness in the public bibliography REST route, present in 1.4.2 and earlier. Reading a bibliography ran its stored citation text through WordPress tag stripping with no length limit, and past roughly 600 KB that operation degrades badly — a single oversized value saved into a published post cost about 12 seconds of pinned CPU on every read, on a route that requires no login and can be requested repeatedly at no cost to the caller. Stored text is now truncated to 64 KB before stripping, so existing bibliographies still render. This is the change that makes updating worthwhile.
* Security: Applied the same 64 KB limit to citation text sent to the formatter endpoint, where any user who can reach the block editor could otherwise tie up a CPU core per request.

The three changes below are hardening. None of them was exploitable; each was a case where the plugin happened to be safe because of how some unrelated code was written, which is a property that quietly stops holding when that code changes.

* Hardening: Bibliography data in a post type registered as non-public is no longer readable without authentication. Published status alone previously satisfied the check. Anyone able to edit the post still has access.
* Hardening: Links generated from citation text are now restricted to `http` and `https`, and any other scheme renders as plain text. Nothing downstream would have caught a `javascript:` link; the only thing preventing one was the URL-detection pattern requiring a literal `http(s)://` prefix, which a later improvement to that pattern could have removed.
* Hardening: PubMed/PMID lookups now use WordPress's safe HTTP client, so every redirect in the chain is validated against the site's own network.
* Escape two Unicode line-separator characters in the JSON-LD and CSL-JSON output blocks. Not a security issue — these blocks are never executed — but the characters terminate a line for a JavaScript parser and would break a consumer that evaluates a block instead of parsing it.
* Update the Block Accessibility Checks (BAC) integration for BAC 4.0, which replaced the registration API and renamed its editor filter hooks. All four bibliography checks — empty bibliography, missing heading, raw URL link text, and all metadata outputs disabled — are now admin-configurable from BAC's unified settings screen.
* The BAC integration now requires Block Accessibility Checks 4.0 or later. On BAC 3.x the integration stays dormant and no bibliography checks appear; Borges itself works normally whether BAC is outdated or not installed at all.
* Add a regression test that validates every shipped bibliography markup format against the block's own deprecation chain, guarding existing posts against "Attempt Block Recovery" prompts after an upgrade.
* Fix the end-to-end test covering the Block Accessibility Checks integration, which silently skipped itself and left the integration without real coverage.
* Add a second WordPress Playground demo that boots the current development build alongside the released-version demo.
* Add a scheduled monitor that verifies each Playground demo link stays reachable.
* Publish hand-verified size, footprint, and runtime-overhead metrics, each paired with the command used to re-derive it, and add a continuous-integration check that fails when the recorded lines-of-code figures or the no-persistent-storage audit drift.

= 1.4.2 =
* Resolve DOI and labeled PMID identifiers embedded in free-text citation pastes through the existing CrossRef and PubMed resolver paths.
* Fall back from embedded-identifier resolution to the heuristic free-text parser before showing unsupported-input guidance.
* Add free-text sample documentation for supported embedded DOI/PMID citation inputs.
* Stabilize numeric citation reorder E2E coverage against editor readiness races.
* Clarify that RIS is supported for export, not import.

= 1.4.1 =
* Clean up after the plugin when it is deleted: uninstalling now removes the plugin's cached data — the formatter and PubMed/PMID transients (across all sites on multisite) and its object-cache groups where the host supports it. Bibliography blocks already saved in your posts are left untouched.

= 1.4.0 =
* Add optional per-entry Cite / Export affordances to the public bibliography: a static, no-JS `<details>` disclosure panel under each entry with the citation text and one-click downloads for RIS, CSL-JSON, BibTeX, and BibLaTeX. Enable it per block with the new "Per-entry Cite / Export" toggle in the Metadata output panel; off by default.
* Pre-compute BibTeX and BibLaTeX export data in the editor so the front-end downloads work without activating the plugin, and derive readable download filenames from each citation (for example, watson1953.ris).
* Only pre-compute export data when the feature is enabled, so bibliographies that do not use Cite / Export incur no extra editor work.
* Use a secure-context-safe helper for generating citation and bibliography IDs.
* Remove a dead, never-loaded duplicate of the PMID resolver (includes/pmid.php) to eliminate a function-redeclare risk.
* Fix DOI imports for works that Crossref labels with a non-standard type such as "monograph" (common for university-press books), which previously failed to import; unrecognized types now map to a sensible CSL type or fall back gracefully instead of aborting the import.
* Fix the default Chicago Notes-Bibliography style (and OSCOLA and MLA) dropping the publication year on every entry; those styles used an issued-date form the formatter does not render. All bundled styles now show the year, guarded by a regression test.
* Title-case author names and titles that Crossref or PubMed return in ALL CAPS (e.g. "TURING" / "I.—COMPUTING MACHINERY AND INTELLIGENCE") so they no longer render shouting; already-cased text, initials, organizations, and non-Latin scripts are left untouched.

= 1.3.4 =
* Refresh the translation template and 19 seed PO/MO locale pairs from current source strings.
* Add i18n artifact validation to CI so POT, PO, MO, and public language-pack wording stay aligned.
* Clarify that bundled seed language files are translator/import material and WordPress.org Languages remains canonical for official packs.
* Update docs for the current maintenance state and archive historical planning notes out of active paths.

= 1.3.3 =
* Restore DOI imports in browser-based WordPress Playground by resolving DOI metadata through Crossref's CORS-friendly CSL transform endpoint.
* Serialize DOI lookups to respect Crossref's public concurrency limit when multiple DOIs are pasted together.
* Add a PubMed/PMID sample to the Playground starter content alongside DOI and BibTeX examples.

= 1.3.2 =
* Add optional Block Accessibility Checks compatibility: soft-detects the BAC plugin and registers four editor checks (empty bibliography, missing heading, raw URL link text, all metadata disabled). Borges works normally when BAC is absent.
* Harden Playwright E2E plugin-row locator to exclude WordPress update notice rows, fixing CI strict-mode violations.
* Regenerate translation template (POT) with 81 strings, up from 41; covers PHP error messages, BAC check strings, BibLaTeX export labels, and citation reorder controls.
* Extend banner generation script with locale and RTL support flags.

= 1.3.1 =
* Raise per-bibliography hard cap from 50 to 200 citations. Bibliographies between 100 and 199 citations now show a dismissible editor notice warning about potential formatting slowness on shared hosting. The per-paste limit (50 entries) is unchanged.

= 1.3.0 =
* Enforce an explicit 50-citation total cap per bibliography block with inline editor warnings, replacing the silent 51-entry formatter cliff.
* Guard all async editor mutation flows (paste/import, manual add, delete, style switch, structured edit) against stale results from superseded in-flight format requests.
* Remove redundant formatter call in the manual-entry add path; the merged bibliography is now formatted once instead of twice.
* Prune non-runtime vendor documentation and images from the release zip and exclude composer.lock, reducing release package weight.
* Cache successful PMID proxy responses and deduplicate pending DOI resolution requests to reduce avoidable network traffic.
* Refactor editor side-effects into focused hooks: useCitationImportActions, useManualCitationActions, and useBibliographyExportActions.
* Extract PHP PMID resolver, cache, and permission logic into includes/pmid.php.

= 1.2.0 =
* Add BibLaTeX export from the editor exports panel.
* Highlight 1.2.0 interoperability features, recent 1.1.x accessibility fixes, and ABNT (Associação Brasileira de Normas Técnicas / NBR 6023:2018) support in the readmes and changelogs.
* Add PMID input resolution through an authenticated WordPress REST proxy to the NCBI/PMC Literature Citation Exporter API.
* Add manual reordering controls for numeric citation styles, including keyboard Alt+Arrow movement.
* Reformat the full bibliography after citation mutations so cached display text, sort order, and metadata stay aligned.
* Improve sort parity with style-family dispatch, author-date tie-breakers, and JS/PHP coordination fixtures.
* Improve accessibility names for saved citation URL links and block toolbar controls.
* Harden Playwright accessibility and Playground smoke tests for shared WordPress Playground servers.
* Add compact matrix coverage for all nine styles, formatter output, export ordering, and PMID REST proxy regression before tagging 1.2.0.

= 1.1.1 =
* Fix Block Accessibility Checks (BAC) integration shipped in 1.1.0: register against the current BAC API, harden the soft opt-in, and load validation checks reliably so the `empty_bibliography` error and `heading_missing` warning fire as documented when the BAC plugin is active.
* Fix editor focus-ring regression so keyboard focus on entry actions remains visible.
* Fix Playground demo blueprint to install from the latest release zip rather than a stale path.

= 1.1.0 =
* Add optional Block Accessibility Checks (BAC) integration: when Troy Chaplin's Block Accessibility Checks plugin is active, the bibliography block registers two authoring-time checks — an error if no citations have been added, and a warning if no heading is set so screen reader users navigating by heading can find the section.
* No functional change when BAC is not installed.

= 1.0.2 =
* Fix browser-based WordPress Playground demos by explicitly enabling the Playground Intl feature in addition to the kitchen-sink PHP extension bundle.
* Keep the GitHub demo blueprint and WordPress.org Preview blueprint aligned for Intl-enabled citation formatting, with regression coverage.
* Clarify translation wording so the readme distinguishes bundled seed PO/MO files from official WordPress.org language packs.

= 1.0.1 =
* Fix Playground/editor bibliography formatting by using the WordPress REST API fetch helper for formatter requests.
* Add the WordPress.org Preview blueprint at the documented assets path with the required PHP extension bundle for citation formatting.

= 1.0.0 =
* Initial public release as Borges Bibliography Builder.
* Add references from DOIs, DOI URLs, BibTeX entries, supported formatted citations, or manual entry.
* Format bibliographies in Chicago Notes-Bibliography, Chicago Author-Date, APA 7, MLA 9, Harvard, Vancouver, IEEE, OSCOLA, and ABNT (Associação Brasileira de Normas Técnicas / NBR 6023:2018).
* Automatically sort entries per style rules and skip duplicate manual or pasted entries.
* Save static HTML output so bibliographies remain readable after plugin deactivation.
* Output Schema.org JSON-LD by default, with optional COinS and CSL-JSON metadata layers.
* Export CSL-JSON, UTF-8 BibTeX, and RIS; copy individual citations or the full bibliography as plain text.
* Preserve Unicode quotation marks in BibTeX exports for Zotero, Mendeley, and other citation-manager imports.
* Provide reference-manager-friendly metadata and exports for Zotero, Mendeley, EndNote, JabRef, BibDesk, LaTeX, and CSL/citeproc workflows.
* Improve accessibility with keyboard navigation, visible focus, block-local notices, semantic bibliography markup, and no deprecated bibliography-entry ARIA role in newly saved output.
* Provide read-only REST API endpoints for programmatic bibliography access.
* Bundle seed interface locale files for translator review/import while using WordPress.org language packs as the canonical availability signal.
* Harden the WordPress.org release package with third-party notices and Plugin Check cleanup.
* Standardize GitHub, Playground, and release-download links on the approved `borges-bibliography-builder` slug and zip name.
* Add CI/runtime coverage for Multisite network activation and expanded PHP utility behavior.
* Confirm compatibility wording through WordPress 7.0 testing.

== Upgrade Notice ==

= 1.18.0 =
Sentence case in APA, Vancouver, and IEEE (check personal names, and tick "Keep title capitalization as entered" where needed); journal abbreviations; OSCOLA repeated authors; citation links without nofollow; new blocks start with an h2. Existing blocks stay valid. No configuration changes required.

= 1.17.0 =
OSCOLA tables of cases, legislation, and treaties; structured data that passes Google's Rich Results Test and links cited works on every site; VoiceOver reads the bibliography as a list again in Safari. No configuration changes required.

= 1.16.0 =
RIS import, BC dates and years before 1000, fuller JSON-LD and COinS for published posts, sorting fixes for Chicago notes, OSCOLA, and ABNT, and several reference-manager import fixes. No configuration changes required.

= 1.15.0 =
Opt-in bulk reformat and bulk deduplicate across posts (REST, abilities, and WP-CLI) with a per-user rate limit, and editing a citation can no longer create a duplicate. No configuration changes required.

= 1.14.0 =
Same-author, same-year works get 2020a and 2020b in APA, Chicago author-date, Harvard, and ABNT, and new read-only WP-CLI commands list, export, and validate bibliographies. No configuration changes required.

= 1.13.0 =
Richer JSON-LD for each cited work, a schema.org `citation` link from the post with Yoast SEO or Rank Math, and a filter for site-wide output defaults. Published posts are enriched as they render. No configuration changes required.

= 1.12.0 =
Bibliographies read correctly in newsletters and feeds, names with particles sort per style, and reformatting after an edit is much faster. Adds opt-in write abilities for WordPress 6.9+. No configuration changes required.

= 1.11.0 =
Stops link previews (Mastodon's, for one) from crediting a cited source as the post's author, and lets bibliographies over 50 citations format again. No configuration changes required.

= 1.10.0 =
Adds OCLC, LCCN, Open Library, and Internet Archive lookups and "Edit fields" for every citation. These lookups contact Open Library and the Internet Archive only when you paste those identifiers. No configuration changes required.

= 1.9.1 =
Imports pasted CSL-JSON and stops italicizing quoted titles such as Chicago web pages. No configuration changes; no new external services.

= 1.9.0 =
Adds a Heading Level setting so the bibliography's heading can be a real heading (h2–h6). Existing bibliographies are unchanged. No configuration changes; no new external services.

= 1.8.2 =
The edit form now drops HTML typed or pasted into citation fields. No configuration changes; no new external services.

= 1.8.1 =
Fixes HTML tags such as `<i>` showing as literal text in a bibliography. No configuration changes; no new external services.

= 1.8.0 =
Moves Chicago, Harvard, OSCOLA, and ABNT to their current editions, adds MLA's three hyphens for repeated authors, and adds an Article number field for journal articles. No configuration changes; no new external services.

= 1.7.0 =
Rewrites all nine citation styles in full, fixes organization authors, blocks that showed as invalid in another editor language, and seven wrong strings in the bundled translations. Adds opt-in REST routes for developers; they are off unless enabled. No new external services.

= 1.6.0 =
Adds PubMed Central, arXiv, ISBN, and BibLaTeX import, plus read-only WordPress Abilities on WordPress 6.9+. Lookups contact arXiv, Open Library, or Google Books only when you paste those identifiers. No configuration changes.

= 1.5.1 =
Adds WordPress 7.1 support and fixes a case where "Copy citation" reported failure although copying was still possible. No security content; no configuration changes.

= 1.5.0 =
Security release; updating is recommended. Fixes an unauthenticated denial-of-service weakness in the public bibliography REST route, present in 1.4.2 and earlier, where oversized stored citation text cost seconds of CPU per read. Also includes hardening; requires Block Accessibility Checks 4.0.

= 1.4.2 =
Improves free-text citation imports by resolving embedded DOI and PMID identifiers before falling back to heuristic parsing.

= 1.2.0 =
Adds BibLaTeX and PubMed/PMID interoperability, numeric citation reordering, stronger sort parity, and explicit ABNT/NBR 6023:2018 docs.

= 1.1.1 =
Fixes Block Accessibility Checks integration and editor focus visibility.

= 1.0.2 =
Fixes WordPress Playground demo formatting when the browser runtime does not load PHP Intl from the extension bundle alone.

= 1.0.1 =
Fixes WordPress.org Playground preview and editor formatter fallback behavior.

= 1.0.0 =
Initial public release of Borges Bibliography Builder.
